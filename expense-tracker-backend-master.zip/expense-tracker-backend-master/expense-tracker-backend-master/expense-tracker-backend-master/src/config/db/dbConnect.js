const mongoose = require("mongoose");

const dbConnect = async () => {
  try {
    
    console.log("MongoDB URL:",  "mongodb+srv://naman0914be21:1556Naman@cluster0.xnafhcz.mongodb.net/expenseTracker");
    
    await mongoose.connect("mongodb+srv://naman0914be21:1556Naman@cluster0.xnafhcz.mongodb.net/expenseTracker", {
      useUnifiedTopology: true,
      useNewUrlParser: true,
    });
    
    console.log("Db is Connected Successfully");
  } catch (error) {
    console.log(`Error ${error.message}`);
    process.exit(1); // Exit the process with a failure code
  }
};

module.exports = dbConnect;
