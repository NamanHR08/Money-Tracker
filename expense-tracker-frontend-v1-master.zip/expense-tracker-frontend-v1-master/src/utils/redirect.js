const redirectUser = (history, path) => {
  history.push(`/${path}`);
};

export default redirectUser;
