//const baseUrl = "http://localhost:5000";
const baseUrl = "https://expenses-tracker-api-v1.herokuapp.com";
export default baseUrl;
